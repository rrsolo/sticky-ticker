bplist00�XUTI-Data�	
_public.utf8-plain-text_$com.apple.traditional-mac-plain-text_com.apple.webarchive_com.apple.flat-rtfd[public.html_ public.utf16-external-plain-textZpublic.rtf_public.utf16-plain-text_"const notesList = document.getElementById('notes-list');

// Function to create a new note element
function createNoteElement(content, timestamp) {
  const note = document.createElement('div');
  note.classList.add('note');

  const noteContent = document.createElement('p');
  noteContent
O"const notesList = document.getElementById('notes-list');// Function to create a new note elementfunction createNoteElement(content, timestamp) {  const note = document.createElement('div');  note.classList.add('note');  const noteContent = document.createElement('p');  noteContentOwbplist00�_WebMainResource�	
^WebResourceURL_WebResourceFrameName_WebResourceData_WebResourceMIMEType_WebResourceTextEncodingName_file:///index.htmlPO<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<title></title>
<meta name="Generator" content="Cocoa HTML Writer">
<meta name="CocoaVersion" content="2113.65">
<style type="text/css">
p.p1 {margin: 0.0px 0.0px 0.0px 0.0px}
p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; min-height: 14.0px}
span.s1 {font: 12.0px Helvetica}
</style>
</head>
<body>
<p class="p1"><span class="s1">const notesList = document.getElementById('notes-list');</span></p>
<p class="p2"><span class="s1"></span><br></p>
<p class="p1"><span class="s1">// Function to create a new note element</span></p>
<p class="p1"><span class="s1">function createNoteElement(content, timestamp) {</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">&nbsp; </span>const note = document.createElement('div');</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">&nbsp; </span>note.classList.add('note');</span></p>
<p class="p2"><span class="s1"></span><br></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">&nbsp; </span>const noteContent = document.createElement('p');</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">&nbsp; </span>noteContent</span></p>
</body>
</html>
Ytext/htmlUUTF-8    ( 7 N ` v � � �-7                           =O�rtfd             TXT.rtf   .k  +      c  {\rtf1\ansi\ansicpg1252\cocoartf2639
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0

\f0\fs24 \cf0 const notesList = document.getElementById('notes-list');\
\
// Function to create a new note element\
function createNoteElement(content, timestamp) \{\
  const note = document.createElement('div');\
  note.classList.add('note');\
\
  const noteContent = document.createElement('p');\
  noteContent\
}   #         TXT.rtf   �`f�          O<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<title></title>
<meta name="Generator" content="Cocoa HTML Writer">
<meta name="CocoaVersion" content="2113.65">
<style type="text/css">
p.p1 {margin: 0.0px 0.0px 0.0px 0.0px}
p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; min-height: 14.0px}
span.s1 {font: 12.0px Helvetica}
</style>
</head>
<body>
<p class="p1"><span class="s1">const notesList = document.getElementById('notes-list');</span></p>
<p class="p2"><span class="s1"></span><br></p>
<p class="p1"><span class="s1">// Function to create a new note element</span></p>
<p class="p1"><span class="s1">function createNoteElement(content, timestamp) {</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">&nbsp; </span>const note = document.createElement('div');</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">&nbsp; </span>note.classList.add('note');</span></p>
<p class="p2"><span class="s1"></span><br></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">&nbsp; </span>const noteContent = document.createElement('p');</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">&nbsp; </span>noteContent</span></p>
</body>
</html>
OF��c o n s t   n o t e s L i s t   =   d o c u m e n t . g e t E l e m e n t B y I d ( ' n o t e s - l i s t ' ) ; 
 
 / /   F u n c t i o n   t o   c r e a t e   a   n e w   n o t e   e l e m e n t 
 f u n c t i o n   c r e a t e N o t e E l e m e n t ( c o n t e n t ,   t i m e s t a m p )   { 
     c o n s t   n o t e   =   d o c u m e n t . c r e a t e E l e m e n t ( ' d i v ' ) ; 
     n o t e . c l a s s L i s t . a d d ( ' n o t e ' ) ; 
 
     c o n s t   n o t e C o n t e n t   =   d o c u m e n t . c r e a t e E l e m e n t ( ' p ' ) ; 
     n o t e C o n t e n t 
 _c{\rtf1\ansi\ansicpg1252\cocoartf2639
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0

\f0\fs24 \cf0 const notesList = document.getElementById('notes-list');\
\
// Function to create a new note element\
function createNoteElement(content, timestamp) \{\
  const note = document.createElement('div');\
  note.classList.add('note');\
\
  const noteContent = document.createElement('p');\
  noteContent\
}ODc o n s t   n o t e s L i s t   =   d o c u m e n t . g e t E l e m e n t B y I d ( ' n o t e s - l i s t ' ) ;   / /   F u n c t i o n   t o   c r e a t e   a   n e w   n o t e   e l e m e n t  f u n c t i o n   c r e a t e N o t e E l e m e n t ( c o n t e n t ,   t i m e s t a m p )   {      c o n s t   n o t e   =   d o c u m e n t . c r e a t e E l e m e n t ( ' d i v ' ) ;      n o t e . c l a s s L i s t . a d d ( ' n o t e ' ) ;       c o n s t   n o t e C o n t e n t   =   d o c u m e n t . c r e a t e E l e m e n t ( ' p ' ) ;      n o t e C o n t e n t      % > e | � � � � �2	�o�<�                           �